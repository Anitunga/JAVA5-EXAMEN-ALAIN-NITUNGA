# LibraryManagementApi
A SpringBoot designed to manage authors and books in a Library.
