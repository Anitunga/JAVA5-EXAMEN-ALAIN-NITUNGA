package com.example.demo.DTO;

import lombok.Data;

@Data
public class AuthorDTO {
    private Long id;
    private String firstname;
    private String lastname;
}
